<?php
  class Application_Controllers_Order extends Lib_BaseController
  {  
    function index()
	 {				
		$this->dislpay_form = true; 
			if(isset($_REQUEST["to_order"])){ 
				$model = new Application_Models_Order;	
				$error=$model->isValidData($_REQUEST); 
				if($error)$this->error=$error; 
				else{			
					
					$order_id=$model->addOrder();
					Lib_SmalCart::getInstance()->setCartData();
					header('Location: /order?thanks='.$order_id);
					exit;
				}
			}
			
			if(isset($_REQUEST["thanks"])){
			  
					$this->message="Ваша заявка <strong>№ ".$_REQUEST["thanks"]."</strong> принята";
					$this->dislpay_form = false;
			}
	 }
  }
