<?php
//контролер главной страницы
  class Application_Controllers_Index  extends Lib_BaseController 
  {
      function index() 
	  {  
		  
      }
  } 

?> 
 
 