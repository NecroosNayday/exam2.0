<h1>Каталог</h1>
<div>
<?

foreach($Items as $item)
		{
			if($i%3==0):?> 
			<div style="clear:both;"></div>
			<?endif;?>
			<div class="product">
				<div class="product_image">
					<a href="/product/<?=$item["url"]?>"><image src="/images/<?=$item["image_url"]?>.jpg" /></a>
				</div>
				<h2>
				<a href="/product/<?=$item["url"]?>"><?=$item["name"]?></a>
				</h2>
				<div class="product_price">
				<?=$item["price"]?> руб.
				</div>
				<div class="product_buy">
				
						<a href="/catalog?in-cart-product-id=<?=$item["id"]?>">В корзину</a>
					
				</div>
			
			</div>
		<?
			$i++;
		}
		?>
	</div>.
	<div class="info">
	<h2>Список заказов отсортированных по дате по убыванию</h2>
	<?php 
		$sql = "SELECT phone, adres, summ FROM `order` ORDER BY `order`.`date` desc";

		 $result = mysql_query($sql)  or die(mysql_error());
		 if($result)
{
    $rows = mysql_num_rows($result); // количество полученных строк
     
    echo "<table><tr><th>Телефон</th><th>Адрес</th><th>Сумма</th></tr>";
    for ($i = 0 ; $i < $rows ; ++$i)
{
    $row = mysql_fetch_row($result);
    echo "<tr>";
        for ($j = 0 ; $j < 3 ; ++$j) echo "<td>$row[$j]</td>";
    echo "</tr>";
}
    echo "</table>";
     
  
    mysql_free_result($result);
}

	 ?>
</div>