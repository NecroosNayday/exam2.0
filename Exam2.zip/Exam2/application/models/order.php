<?php

 class Application_Models_Order extends Lib_DateBase 
  {	  
		private $fio;
		private $email;
		private $phone;
		private $adres;
		
		
		function isValidData($array_data){
		
			if(!preg_match("/^[A-Za-z0-9._-]+@[A-Za-z0-9_-]+.([A-Za-z0-9_-][A-Za-z0-9_]+)$/", $array_data['email'])){ 
			  $error="E-mail не существует!";	
			} 
		
			elseif(!trim($array_data['adres'])){ 
			  $error="Введите адресс!";	
			}
		
			if($error)return $error;
			else{
				$this->fio=trim($array_data['fio']);
				$this->email=trim($array_data['email']);
				$this->phone=trim($array_data['phone']);
				$this->adres=trim($array_data['adres']);
				return false;
			}		
     
		}
		
	
	function addOrder(){
		$date = mktime();
			
		$item_position = new Application_Models_Product();
		
		foreach($_SESSION['cart'] as $product_id=>$count){
			$price=$item_position->getProductPrice($product_id);
			$product_positions[$product_id] = array(
			"price"=>$price,
			"count"=>$count,
			);
		}
	
		$order_content=addslashes(serialize($product_positions));
	
		$cart = new Application_Models_Cart();	
		$summ = $cart->getTotalSumm();
		
		
		$array=array(
			"name"=>$this->fio, 
			"email"=>$this->email,
			"phone"=>$this->phone,
			"adres"=>$this->adres,
			"date"=>$date,
			"summ"=>$summ,
			"order_content"=>$order_content
		);
		
	
		parent::build_query("INSERT INTO `order` SET",$array);
		$id=parent::insert_id(); 
		
		if($id) $cart->clearCart();
		return $id;
	}
	
  } 
