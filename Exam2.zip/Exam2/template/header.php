<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="/template/style.css" type="text/css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				
			</div>	
			<div class="smalcart">
				<strong>Товаров в корзине:</strong>	<?=$smal_cart['cart_count']?> шт.
				<br/>
				<strong>На сумму:</strong>	<?=$smal_cart['cart_price']?> руб.	
				<br/>
				<a href='/cart'>Оформить заказ</a>
			</div>	
			<div class="menu">
				<?=$menu?>
			</div>	

		</div>
		<div id="content">
		<hr/>
			
	