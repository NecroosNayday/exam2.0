<?php

 function __autoload ($class_name) 
 {
    $path=str_replace("_", "/", strtolower($class_name));

    if (file_exists($path.".php")) {
   
     include_once($path.".php");
	}
	else{

	header("HTTP/1.0 404 Not Found");
	echo "К сожалению такой страницы не существует. [".PATH_SITE.$path.".php ]";
	exit;
	}
 }


 define('PATH_SITE', $_SERVER['DOCUMENT_ROOT']); 
 define('HOST', 'localhost'); 	
 define('USER', 'root'); 	
 define('PASSWORD', ''); 
 define('NAME_BD', 'LifeExampleShop');	
 $connect = mysql_connect(HOST, USER, PASSWORD)or die("Невозможно установить соединение c базой данных".mysql_error( ));
 mysql_select_db(NAME_BD, $connect) or die ("Ошибка обращения к базе ".mysql_error());	
 mysql_query('SET names "utf8"'); 

?>