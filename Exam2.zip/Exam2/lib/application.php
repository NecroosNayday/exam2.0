<?php
 class Lib_Application  
 {
    private function getRoute() 
    {
	   if (empty($_GET['route']))
       {
           $route = 'index';
	   }
         else
	   {
            $route = $_GET['route'];				
			$rt=explode('/', $route);
			$route=$rt[(count($rt)-1)]; 
						if($rt[(count($rt)-2)]=="product"){			
				 $sql = "SELECT * FROM product WHERE url like '$route'";
				 $result = mysql_query($sql)  or die(mysql_error());
			
				 if($row = mysql_fetch_object($result))
				 {
					 $_REQUEST['id']=$row->id;
					 $route="product";
				 }
				
			}
	   }
		return $route;
    }

    private function getController()
	{       
       $route=$this->getRoute();
	   $path_contr = 'application/controllers/';
       $controller= $path_contr. $route . '.php';
       return $controller;
    }
	 
	public function getView()
	{
       $route=$this->getRoute();
	   $path_view = 'application/views/' ;
       $view = $path_view . $route . '.php';
       return $view;
    }
	 
	public function Run()
	{ 
	   session_start();
	   $controller=$this->getController();
	   $cl=explode('.', $controller);
	   
	   $cl=$cl[0]; 
    
	   $name_contr=str_replace("/", "_", $cl);
	   $contr=new $name_contr;
       $contr->index();
	   $member=$contr->member;
	    
		
	   return $member;
	
	}
 }
 

?>